using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HitBox : MonoBehaviour
{
    public enum ehitboxType
    {
        AttackBox,
        TakeAttackBox,
        TrapBox,
    }
    [SerializeField] ehitboxType hitboxType;
    [SerializeField] bool Player;
    [SerializeField] bool Monster;
    [SerializeField] bool Boss;
     Monster monster;
     MovePlayer movePlayer;
     MoveBoss moveBoss;
    private void Awake()
    {
        monster = GetComponentInParent<Monster>();
        movePlayer = GetComponentInParent<MovePlayer>();
        moveBoss = GetComponentInParent<MoveBoss>();
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (Player)
        {
            movePlayer.Player_TriggerEnter(hitboxType, collision);
        }
        else if (Monster)
        {
            monster.Monster_TriggerEnter(hitboxType, collision);
        }
        else if (Boss)
        {
            moveBoss.Boss_TriggerEnter(hitboxType, collision);
        }
        else
        {
            return;
        }
    }
    private void OnTriggerExit2D(Collider2D collision)
    {
        if (Player)
        {
            movePlayer.Player_TriggerExit(hitboxType, collision);
        }
        else
        {
            return;
        }
    }





}
