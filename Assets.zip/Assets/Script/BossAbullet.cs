using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BossAbullet : MonoBehaviour
{
    [SerializeField] float Bullet_Speed;
    Rigidbody2D rigid;

    private float BossPos;
    private float PlaeyrPos;
    Vector3 dir;

    private void Start()
    {
        rigid = GetComponent<Rigidbody2D>();
        BossPos = BossManager.instance.SendBossPos();
        PlaeyrPos = BossManager.instance.SendPlayerPos();
        dir = Shot_dir();
    }

    void Update()
    {
        rigid.velocity =  dir *  Bullet_Speed;
        Destroy(gameObject, 2f);
    }

    private Vector3 Shot_dir()
    {
        Vector3 SendDir = new Vector3 (0,0,0);
        if (BossPos > PlaeyrPos)
        {
            SendDir.x = -1f;
            transform.localScale = new Vector3(-1, 1, 1);
        }
        else if (BossPos < PlaeyrPos)
        {
            SendDir.x = 1f;
            transform.localScale = new Vector3(-1, 1, 1);
        }
        return SendDir;
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("Player"))
        {
            Destroy(gameObject);
        }
    }






}
