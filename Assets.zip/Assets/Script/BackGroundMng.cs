using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BackGroundMng : MonoBehaviour
{
    Material matFirst;
    Material matSecond;
    Material matThrid;
    [SerializeField] private float speedFirst;
    [SerializeField] private float speedSecond;
    [SerializeField] private float speedThrid;
    GameObject objBackGround;
    [SerializeField] Transform PlayerPos;
    void Start()
    {
        objBackGround = GameObject.Find("BackGround");
        Transform trsFirst = objBackGround.transform.Find("First");
        Transform trsSecond = objBackGround.transform.Find("Second");
        Transform trsThrid = objBackGround.transform.Find("Third");
        SpriteRenderer sprFirstRenderer = trsFirst.GetComponent<SpriteRenderer>();
        SpriteRenderer sprSecondRenderer = trsSecond.GetComponent<SpriteRenderer>();
        SpriteRenderer sprThirdRenderer = trsThrid.GetComponent<SpriteRenderer>();
        matFirst = sprFirstRenderer.material;
        matSecond = sprSecondRenderer.material;
        matThrid = sprThirdRenderer.material;
    }
    void Update()
    {
        Vector3 PlayerPosCheck = PlayerPos.position;
        Vector2 vecFirst = matFirst.mainTextureOffset;
        Vector2 vecSecond = matSecond.mainTextureOffset;
        Vector2 vecThird = matThrid.mainTextureOffset;
        vecFirst.x = PlayerPosCheck.x * speedFirst;
        vecSecond.x = PlayerPosCheck.x * speedSecond;
        vecThird.x = PlayerPosCheck.x * speedThrid;
        vecFirst.x = Mathf.Repeat(vecFirst.x, 1.0f);
        vecSecond.x = Mathf.Repeat(vecSecond.x, 1.0f);
        vecThird.x = Mathf.Repeat(vecThird.x, 1.0f);
        matFirst.mainTextureOffset = vecFirst;
        matSecond.mainTextureOffset = vecSecond;
        matThrid.mainTextureOffset = vecThird;
    }

}
