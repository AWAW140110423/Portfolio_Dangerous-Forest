using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BossManager : MonoBehaviour
{
    public static BossManager instance;
    [SerializeField] Transform playerpos;
    [SerializeField] Transform bosspos;
    float Getpos;
    private void Awake()
    {
        if (instance == null)
        {
            instance = this;
        }
        else
        {
            Destroy(gameObject);
        }
    }
    private float GetPlayerPos(Transform _Pos)
    {
        float pos = _Pos.position.x;
        return pos;
    }
    public float SendPlayerPos()
    {
        float Ppos = GetPlayerPos(playerpos);
        return Ppos;
    }
    private float GetBossPos(Transform _Pos)
    {
        float pos = _Pos.position.x;
        return pos;
    }
    public float SendBossPos()
    {
        float Bpos = GetBossPos(bosspos);
        return Bpos;
    }
    public Vector3 ShotPlayerPos()
    {
        Vector3 pos = playerpos.position;
        return pos;
    }
}
