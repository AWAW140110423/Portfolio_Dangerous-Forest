using System.Collections;
using System.Collections.Generic;
using System.Threading;
using Unity.VisualScripting;
using UnityEditor;
using UnityEngine;
using UnityEngine.UI;

public class MoveBoss : MonoBehaviour
{
    [Header("���� �⺻ �Ӽ�")]
    [SerializeField] float Boss_MaxHp; // �ִ�ü��
    [SerializeField] float Boss_NowHp; // ����ü��
    [SerializeField] float Boss_MoveSpeed; // �̵��ӵ�
    [SerializeField] float Boss_Damage; // ���� ������


    [Header("���� ���� ����")]
    [SerializeField] float BossNomalAtk_time = 3f; // �⺻���� ��Ÿ��
    float BossNomalAtk_timer; // �⺻���� Ÿ�̸�

    [Header("���� ��ų ����")]
    [SerializeField] GameObject Skill_Th; // ��ų 1 ����ü
    [SerializeField] float BossSkillA;
    [SerializeField] float BossSkillB;
    [SerializeField]  float BossSkillA_Timer = 7f;
    float BossSkillB_Timer = 11f;

    [Header("���� �������")]
    bool BossMoveStop; // ���� �̵� ����
    float BossStop_Timer;
    Vector2 bossFormRay;
    Vector2 bossToRay;
    private float Monster_HitTimer;
    private float Monster_HitTime = 0.1f;

    [Header("����UI")]
    [SerializeField] Image BossHpbarFill;


    Renderer renderer;
    BoxCollider2D collbox;
    Rigidbody2D rigid;
    RaycastHit2D hit;
    Vector2 movedir;
    Animator anim;
    float Getpos;
    Vector3 BossLook = new Vector3 (1,1,0);
    float dir = 1; // ������ �ٶ󺸴� ����

    private void Awake()
    {
        Boss_NowHp = Boss_MaxHp;
        renderer = GetComponent<Renderer>();
        rigid = GetComponent<Rigidbody2D>();
        collbox = GetComponent<BoxCollider2D>();
        anim = GetComponent<Animator>();
    }

    private void Update()
    {
        BossHpFill();

        BossCehckForward();
        FindPlayer();
        BossMove();
        BossTiemr();
        BossNomalAtk();
        BossSkillControal();

    }

    private void BossHpFill()
    {
        BossHpbarFill.fillAmount = Boss_NowHp / Boss_MaxHp;
    }

    public void Boss_TriggerEnter(HitBox.ehitboxType _type, Collider2D _collision)
    {

        if (_type == HitBox.ehitboxType.AttackBox) // �÷��̾� ���� ������ Ȯ��
        {
            if (_collision.gameObject.layer == LayerMask.NameToLayer("Attack"))
            {
                renderer.material.color = Color.red;
                Monster_HitTimer = Monster_HitTime;
                Boss_NowHp -= _collision.gameObject.GetComponentInParent<MovePlayer>().Player_SendDamage();
                Boss_dieCheck();
            }
        }

    }

    private void Boss_dieCheck()
    {
        if(Boss_NowHp < 0)
        {
            anim.SetTrigger("BossDie");
        }
    }

    public void BossDie()
    {
        Destroy(gameObject);
        PlayerManager.instance.GameClearPoPup();
    }


    public void Boss_RefDamage(float Num)
    {
        Boss_NowHp -= Num;
        renderer.material.color = Color.red;
        Monster_HitTimer = Monster_HitTime;
        Boss_dieCheck();
    }



    public float Boss_SendDamage()
    {
        float damage = Boss_Damage;
        return damage;
    }


    private void BossCehckForward() // ������ ����üũ
    {
        Getpos = BossManager.instance.SendPlayerPos();

        if (BossMoveStop == true || BossStop_Timer > 0)
        {
            return;
        }
        else if (transform.position.x > Getpos)
        {
            dir = 1;
        }
        else if (transform.position.x <= Getpos)
        {
            dir = -1;
        }
        transform.localScale = new Vector3 (dir,1,1);
    }

    private void BossTiemr()
    {
        if (BossNomalAtk_timer > 0)
        {
            BossNomalAtk_timer -= Time.deltaTime;
            if(BossNomalAtk_timer < 0)
            {
                BossNomalAtk_timer = 0;
            }
        }
        if (BossSkillA_Timer > 0)
        {
            BossSkillA_Timer -= Time.deltaTime;
            if (BossSkillA_Timer < 0)
            {
                BossSkillA_Timer = 0;
            }
        }
        if (Monster_HitTimer > 0)
        {
            Monster_HitTimer -= Time.deltaTime;
            if (Monster_HitTimer < 0)
            {
                Monster_HitTimer = 0;
                renderer.material.color = Color.white;

            }
        }
        if (BossStop_Timer > 0)
        {
            BossStop_Timer -= Time.deltaTime;
            if (BossStop_Timer < 0)
            {
                BossStop_Timer = 0;
                BossMoveStop = false;
            }
        }
    } // �������� ���Ǵ� Ÿ�̸� ���� �Լ�

    private void FindPlayer() // �÷��̾ ã�� Raycast
    {
        bossFormRay = new Vector2(transform.position.x, transform.position.y + 1);
        bossToRay = dir == 1 ? Vector2.left : Vector2.right;
        hit = Physics2D.Raycast
        (bossFormRay, bossToRay, 5, LayerMask.GetMask("Player"));
    }
    private void BossMove() // ������ �÷��̾� �������� �����̴� �Լ�
    {
        if (BossMoveStop == true || BossStop_Timer > 0 || collbox.IsTouchingLayers(LayerMask.GetMask("Player")))
        {
            movedir.x = 0;
        }
        else if (hit)
        {
            movedir.x = -dir;
        }
        else
        {
            movedir.x = 0;
        }
        rigid.velocity = movedir;
        int Movecheck = (int)movedir.x;
        anim.SetInteger("move", Movecheck);
    }

    private void BossNomalAtk() // ������ �⺻���� �Լ�
    {
        if (collbox.IsTouchingLayers(LayerMask.GetMask("Player"))
            && BossNomalAtk_timer == 0 && BossMoveStop == false)
        {
            anim.SetTrigger("NomalAttack");
            BossNomalAtk_timer = BossNomalAtk_time;
            BossStop_Timer = 1f;
        }
    }

    private void BossSkillControal()
    {
        if (BossMoveStop == true)
        {
            return;
        }
        else if (BossSkillA_Timer == 0)
        {
            BossMoveStop = true;
            anim.SetTrigger("SkillA");
            BossSkillA_Timer = 7f;
        }
    }


    public void BossA_Skill_1()
    {
        Vector3 Cpos = new Vector3(gameObject.transform.position.x, gameObject.transform.position.y + 1f, 0f);
        Instantiate(Skill_Th, Cpos, Quaternion.identity, gameObject.transform);
    }

    public void BossStopSetFalse()
    {
        BossMoveStop = false;
    }



}
