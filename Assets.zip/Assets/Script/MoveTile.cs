using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MoveTile : MonoBehaviour
{
    [SerializeField] float TurnTime; // ȸ�� ����
    float Turntimer;
    [SerializeField] bool TileMoveCheck; // ������ ���� //trun ���� //false �¿�
    float IsTurn;
    [SerializeField] float TileMoveSpeed; // ������ �ӵ�
    Rigidbody2D rigid;
    Vector3 moveDir;

    private void Awake()
    {
        rigid = GetComponent<Rigidbody2D>();
    }

    private void TileTimers()
    {
        if ( Turntimer > 0 )
        {
            Turntimer -= Time.deltaTime;
            if( Turntimer < 0 )
            {
                Turntimer = 0;
            }
            return;
        }
        TileMoveSpeed *= -1;
        Turntimer = TurnTime;
    }

    void Update()
    {
        TileTimers();
        TileMove();
    }

    private void TileMove()
    {
        if(TileMoveCheck == true)
        {
            moveDir.x = 1;
            moveDir.y = 0;
            transform.position += moveDir * TileMoveSpeed * Time.deltaTime;
        }
        else if(TileMoveCheck == false)
        {
            moveDir.x = 0;
            moveDir.y = 1;
            transform.position += moveDir * TileMoveSpeed * Time.deltaTime;
        }
    }



}
