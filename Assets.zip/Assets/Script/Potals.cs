using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Potals : MonoBehaviour
{
    public static Potals instance;
    bool collsionCheck;

    private void Awake()
    {
        if (instance == null)
        {
            instance = this;
        }
        else
        {
            Destroy(gameObject);
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Player"))
        {
            collsionCheck = true;
        }
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.CompareTag("Player"))
        {
            collsionCheck = false;
        }
    }

    public bool CheckPotal(bool _bool)
    {
        _bool = collsionCheck;
        return _bool;
    }




}
