using System.Collections;
using System.Collections.Generic;
using System.Threading;
using TMPro;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class MovePlayer : MonoBehaviour
{
    [Header(" �÷��̾� ���� ����")]
    [SerializeField] float Player_PowerStat = 0;
    [SerializeField] float Player_HpStat = 0;
    [SerializeField] float Player_Maxhp; // �÷��̾��� �ִ� ü��
    [SerializeField] float Player_Nowhp; // �÷��̾��� ���� ü��
    [SerializeField] float Player_Healing;
    [SerializeField] float Player_Speed; // �÷��̾��� �ӵ�
    [SerializeField] float Player_Damage; // �÷��̾��� ���� ������
    [SerializeField] float Player_DamagePThree = 0; // 3Ÿ �߰� ������
    [SerializeField] float Player_RefDamage = 0;
    [SerializeField] float Jump_Force; // �÷��̾��� ���� ����
    [SerializeField] float Raylength; // �÷��̾ ���鿡 ��Ҵ��� Ȯ���ϴ� ������ ����
    [SerializeField] float  Htiemr = 15f;//�÷��̾� ��� Ÿ�̸�
    [SerializeField] float  PotionCoolTimer;//�÷��̾� ��� Ÿ�̸�
    [SerializeField] bool IsGround; // �÷��̾ ���� ��Ҵ��� Ȯ���մϴ�.
    bool IsJump; // �÷��̾��� ���� ����
    [SerializeField] List<bool> PlusCheck; // �÷��̾� �߰����� Ȯ��



    [Header("�뽬")] // ���� �̿ϼ���
    [SerializeField] float Dash_Last_Time = 0.3f; // �뽬 �����ð�
    [SerializeField] float Dash_Cooldown = 0.6f; // �뽬 ��Ÿ��
    [SerializeField] Vector2 DashForce = new Vector2(3, 0); // �뽬 �ӵ�
    float Dash_Last_Timer = 0.0f; //Ÿ�̸�
    float Dash_Cooldown_Timer = 0.0f; //Ÿ�̸�
    bool IsDash;

    [Header("���ݱ��")]
    float AttackCount;
    [SerializeField] float Attack_MotionStop = 0.3f; // ���ݽ� �����ð�
    float Attack_MotionStop_Timer = 0.0f;
    [SerializeField] float ReAttack_Cooldown = 0.5f; // ���� ��Ÿ��
    float ReAttack_Cooldown_Timer = 0.0f;
    [SerializeField] float AttackType_Reset = 1.5f; // 3Ÿ ��Ÿ�� �ʱ�ȭ
    float AttackType_Reset_Timer;

    [Header("�����")]
    [SerializeField] float Defense_MotionStop = 0.5f; // ���� �����ð�
    float Defense_MotionStop_Timer;
    [SerializeField] float Defense_Cooldown = 5.0f; // ��� ��Ÿ��
    float Defense_Cooldown_Timer;

    [Header("��ų����")]
    [SerializeField] float DoubleCastCheck = 0.2f; // 2�� �ɽ��� ����
    float DoubleCastTimer;

    [Header("�÷��̾� ����")]
    [SerializeField] float Hitting_Time = 0.1f;
    float Hitting_Timer = 0f;
    [SerializeField] float TrapH_Time = 2f;
    float TrapH_Timer = 0f;


    [Header("�÷��̾� ����")]
    [SerializeField] float TrapDmg;
    [SerializeField] float SlowForce;
    bool Trap_Istrue;

    [Header("�÷��̾� ���� ��ġ")]
    [SerializeField] List<GameObject> PotalPos;
    [SerializeField] List<GameObject> PoPup;


    [Space] // ��� ����Ʈ
    [SerializeField] Transform defpos;
    [SerializeField] GameObject defPrefab;

    [Space] // �÷��̾� ���� UI
    [SerializeField] Image playerHpFill;
    [SerializeField] Image playerXpFill;
    [SerializeField] Image playerAttackFill;
    [SerializeField] Image playerDefFill;
    [SerializeField] Image playerDashFill;
    [SerializeField] Image playerPotionFill;

    [SerializeField] TMP_Text playerAtkText;
    [SerializeField] TMP_Text playerDefText;
    [SerializeField] TMP_Text playerDashText;
    [SerializeField] TMP_Text playerPotionText;
    [SerializeField] TMP_Text playerGoldText;
    //[SerializeField] TMP_Text playerStatText;

    BoxCollider2D collbox;
    Rigidbody2D rigid;
    Animator anim;
    Renderer Hitcolor;
    Vector2 moveDir;
    private int StageNow;
    private bool saveDmg;
    private bool IsPotal; //��Ż Ȱ��ȭ ����
    private float verticalVelocity = 0f; // �������� �������� ��


    //private void OnDrawGizmos()
    //{
    //    if(Gizmocheck == true)
    //    {
    //        Debug.DrawLine(new Vector3 (collbox.bounds.center.x , collbox.bounds.min.y , 0),
    //            new Vector3(collbox.bounds.center.x, collbox.bounds.min.y, 0) - new Vector3(0, Raylength), Color.red);
    //    }
    //}
    private void Awake()
    {
        Player_Nowhp = Player_Maxhp;
        rigid = GetComponent<Rigidbody2D>();
        anim = GetComponent<Animator>();
        collbox = GetComponent<BoxCollider2D>();
        defpos = GetComponent<Transform>();
        Hitcolor = GetComponent<Renderer>();
    }

    void Update()
    {
        Player_faillCheck();
        Player_Diecheck();
        Player_InforUi();
        Player_TextSet();
        GetPlusStat();
        checkGravity();
        Player_checkGrounded();
        CheckTrap();
        Cooldown();
        Player_Defense();
        Player_Attack();
        Player_Dash();
        Player_DashCast();
        Player_moving();
        Player_jump();
        Plaeyr_Healing();
        Player_Potion();

        PotalCheck();
        doAnimi();
        Player_checkDirection();
    }
    private void PotalCheck()
    {
        if (IsPotal == false)
        {
            return;
        }
        else if (Input.GetKeyDown(KeyCode.W) && PlayerManager.instance.SendStage() == 1 )
        {
            PoPUpActive(1);
        }
        else if (Input.GetKeyDown(KeyCode.W) && PlayerManager.instance.SendStage() == 2)
        {
            PoPUpActive(2);
        }
        else if (Input.GetKeyDown(KeyCode.W) && PlayerManager.instance.SendStage() == 3)
        {
            PoPUpActive(3);
        }
    }
    private void PotalTeleport(int Num)
    {
        gameObject.transform.position = PotalPos[Num - 1].transform.position;
        GetCharic(PlayerManager.instance.C_SetRandom());

    }
    private void GetCharic(float Random)
    {
        if (Random == 3)
        {
            Player_DamagePThree += 3;
        }
        else if (Random == 4)
        {
            Player_RefDamage += 2;
        }
        else if (Random == 5)
        {
            ReAttack_Cooldown *= 0.7f;
        }
        else if (Random == 6)
        {
            Defense_Cooldown *= 0.7f;
            Dash_Cooldown *= 0.7f;
        }
        else
        {
            PlayerManager.instance.GetUp_Charic(Random);
        }
    }

    private void PoPUpActive(int Num)
    {
        PoPup[0].SetActive(true);
        StageNow = Num;
    }
    public void GetPopUpButYes()
    {
        PotalTeleport(StageNow);
        PlayerManager.instance.StageUp();
        PoPup[0].SetActive(false);
    }
    public void GetPopUpButNo()
    {
        PoPup[0].SetActive(false);
    }

    private void GetPlusStat() // ��� ������ ��������
    {
        if (PlayerManager.instance.SendTool(0) == true && PlusCheck[0] == false) // ���� ü������
        {
            Player_Maxhp += PlayerManager.instance.SendMaxHp();
            Player_Nowhp += PlayerManager.instance.SendMaxHp();
            PlusCheck[0] = true;
        }
        else if (PlayerManager.instance.SendTool(1) == true && PlusCheck[1] == false) // ���� �������
        {
            Player_Healing += PlayerManager.instance.SendHealing();
            PlusCheck[1] = true;
        }
        else if(PlayerManager.instance.SendTool(2) == true && PlusCheck[2] == false) // �Ź� �̼�����
        {
            Player_Speed += PlayerManager.instance.SendSpeed();
            PlusCheck[2] = true;
        }
        else if (PlayerManager.instance.SendTool(3) == true && PlusCheck[3] == false) // �� ���ݷ�����
        {
            Player_Damage += PlayerManager.instance.SendDamage();
            PlusCheck[3] = true;
        }

    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("MoveTile"))
        {
            gameObject.transform.SetParent(collision.gameObject.transform);
        }
    }
    private void OnCollisionExit2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("MoveTile"))
        {
            gameObject.transform.SetParent(null);
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("Potal"))
        {
            IsPotal = true;
        }
        if (collision.gameObject.CompareTag("Shop"))
        {
            PlayerManager.instance.ShopOpenGet(true);
        }
    }
    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("Potal"))
        {
            IsPotal = false;
        }

        if (collision.gameObject.CompareTag("Shop"))
        {
            PlayerManager.instance.ShopOpenGet(false);
        }
    }

    private void Player_faillCheck()
    {
        if(transform.position.y < -20f)
        {
            Player_DieNext();
        }
    }


    public void Player_TriggerEnter(HitBox.ehitboxType _type, Collider2D _collision)//��Ʈ
    {
        if (_type == HitBox.ehitboxType.TakeAttackBox)
        {
            if (_collision.gameObject.layer == LayerMask.NameToLayer("TakeAttack"))
            {
                if (Defense_MotionStop_Timer > 0)
                {
                    Player_DefEffect();
                    if(Player_RefDamage > 0)
                    {
                        _collision.gameObject.GetComponentInParent<Monster>().Monster_RefDamage(Player_RefDamage);
                    }
                    return;
                }
                Player_HitAni();
                Player_Nowhp -= _collision.gameObject.GetComponentInParent<Monster>().Monster_SendDamage()/2;
            }
            else if (_collision.gameObject.layer == LayerMask.NameToLayer("Trap"))
            {
                Trap_Istrue = true;
                SlowForce = 0.5f;
            }
            else if (_collision.gameObject.layer == LayerMask.NameToLayer("BossAttack"))
            {
                if (Defense_MotionStop_Timer > 0)
                {
                    Player_DefEffect();
                    if (Player_RefDamage > 0)
                    {
                        _collision.gameObject.GetComponentInParent<MoveBoss>().Boss_RefDamage(Player_RefDamage);
                    }
                    return;
                }
                Player_HitAni();
                Player_Nowhp -= _collision.gameObject.GetComponentInParent<MoveBoss>().Boss_SendDamage();
            }
           
        }
    }
    public void Player_TriggerExit(HitBox.ehitboxType _type, Collider2D _collision)//��Ʈ�ڽ�
    {
        if (_type == HitBox.ehitboxType.TakeAttackBox)
        {
            if (_collision.gameObject.layer == LayerMask.NameToLayer("Trap"))
            {
                SlowForce = 1;
                Trap_Istrue = false;
            }
        }
    }
    private void CheckTrap()
    {
        if(Trap_Istrue == true && TrapH_Timer == 0)
        {
            TrapH_Timer = TrapH_Time;
            Player_Nowhp -= TrapDmg;
            Player_HitAni();
        }
    }
    private void Player_HitAni()
    {
        Hitcolor.material.color = Color.red;
        Hitting_Timer = Hitting_Time;
        
    }
    private void Player_Diecheck()// �÷��̾� ��� Ȯ��
    {
        if(Player_Nowhp <= 0)
        {
            anim.SetTrigger("PlayerDie");
            Player_DieNext();
        }
    }
    public void Player_DieAnim()//�÷��̾� ��� ���ϸ��̼�
    {
        Destroy(gameObject);
    }
    private void Player_DieNext()//�÷��̾� ����� ���� ����
    {
        PlayerManager.instance.GameOverPoPup();
    }
    private void Player_DefEffect() // �÷��̾� ��� ����Ʈ
    {
        Instantiate(defPrefab, new Vector3(transform.position.x + 0.3f,transform.position.y + 0.8f, 0), Quaternion.identity , defpos);
    }
    private void Player_Defense()
    {
        if(Defense_Cooldown_Timer > 0 || DoubleCastTimer > 0 || Dash_Last_Timer > 0)
        {
            return;
        }
        else if (Input.GetKeyDown(KeyCode.K) && IsGround == true)
        {
            anim.SetTrigger("Defense");
            DoubleCastTimer = DoubleCastCheck;
            Defense_MotionStop_Timer = Defense_MotionStop;
            Defense_Cooldown_Timer = Defense_Cooldown;
            rigid.velocity = new Vector2(0, 0);
        }

    }//�÷��̾� ���
    private void Player_Attack()
    {
        if (IsGround == false || ReAttack_Cooldown_Timer > 0 || DoubleCastTimer > 0 || Dash_Last_Timer > 0)
        {
            return;
        }
        else if (Input.GetKeyDown(KeyCode.J) && AttackCount == 0 )
        {
            if (saveDmg == true)
            {
                Player_Damage -= Player_DamagePThree;
                saveDmg = false;
            }
            anim.SetTrigger("Attack1");
            DoubleCastTimer = DoubleCastCheck;
            AttackType_Reset_Timer = AttackType_Reset;
            Attack_MotionStop_Timer = Attack_MotionStop;
            ReAttack_Cooldown_Timer = ReAttack_Cooldown;
            AttackCount = 1;
            rigid.velocity = new Vector2(0, 0);
        }
        else if (Input.GetKeyDown(KeyCode.J) && AttackCount == 1)
        {
            anim.SetTrigger("Attack2");
            DoubleCastTimer = DoubleCastCheck;
            AttackType_Reset_Timer = AttackType_Reset;
            Attack_MotionStop_Timer = Attack_MotionStop;
            ReAttack_Cooldown_Timer = ReAttack_Cooldown;
            AttackCount = 2;
            rigid.velocity = new Vector2(0, 0);
        }
        else if (Input.GetKeyDown(KeyCode.J) && AttackCount == 2)
        {
            saveDmg = true;
            Player_Damage += Player_DamagePThree;
            anim.SetTrigger("Attack3");
            DoubleCastTimer = DoubleCastCheck;
            AttackType_Reset_Timer = AttackType_Reset;
            Attack_MotionStop_Timer = Attack_MotionStop;
            ReAttack_Cooldown_Timer = ReAttack_Cooldown;
            AttackCount = 0;
            rigid.velocity = new Vector2(0, 0);
        }
    }// �÷��̾� ����
    private void Cooldown()
    {
        if (Dash_Last_Timer > 0.0f) //�뽬 ���ӽð�
        {
            Dash_Last_Timer -= Time.deltaTime;
            if (Dash_Last_Timer < 0.0f)
            {
                Dash_Last_Timer = 0.0f;
            }
        }

        if (Dash_Cooldown_Timer > 0.0f) //�뽬 ��Ÿ�� �ʱ�ȭ
        {
            Dash_Cooldown_Timer -= Time.deltaTime;
            if (Dash_Cooldown_Timer < 0.0f)
            {
                Dash_Cooldown_Timer = 0.0f;
            }
            playerDashFill.fillAmount = 1 - Dash_Cooldown_Timer / Dash_Cooldown;
        }

        if (Attack_MotionStop_Timer > 0.0f)
        {
            Attack_MotionStop_Timer -= Time.deltaTime;
            if(Attack_MotionStop_Timer < 0.0f)
            {
                Attack_MotionStop_Timer = 0.0f;
            }
        }

        if (ReAttack_Cooldown_Timer > 0.0f)
        {
            ReAttack_Cooldown_Timer -= Time.deltaTime;
            if (ReAttack_Cooldown_Timer < 0.0f)
            {
                ReAttack_Cooldown_Timer = 0.0f;
            }
            playerAttackFill.fillAmount = 1 - ReAttack_Cooldown_Timer / ReAttack_Cooldown;
        }

        if (AttackType_Reset_Timer > 0.0f)
        {
            AttackType_Reset_Timer -= Time.deltaTime;
            if (AttackType_Reset_Timer <= 0.0f)
            {
                AttackCount = 0;
                AttackType_Reset_Timer = 0.0f;
            }
        }

        if (Defense_Cooldown_Timer > 0.0f)
        {
            Defense_Cooldown_Timer -= Time.deltaTime;
            if (Defense_Cooldown_Timer < 0.0f)
            {
                Defense_Cooldown_Timer = 0.0f;
            }
            playerDefFill.fillAmount = 1 - Defense_Cooldown_Timer / Defense_Cooldown;
        }

        if (PotionCoolTimer > 0.0f)
        {
            PotionCoolTimer -= Time.deltaTime;
            if (PotionCoolTimer < 0.0f)
            {
                PotionCoolTimer = 0.0f;
            }
            playerPotionFill.fillAmount = 1 - PotionCoolTimer / 3f;
        }

        if (Defense_MotionStop_Timer > 0.0f)
        {
            Defense_MotionStop_Timer -= Time.deltaTime;
            if (Defense_MotionStop_Timer < 0.0f)
            {
                Defense_MotionStop_Timer = 0.0f;
            }
        }

        if (DoubleCastTimer > 0.0f)
        {
            DoubleCastTimer -= Time.deltaTime;
            if (DoubleCastTimer < 0.0f)
            {
                DoubleCastTimer = 0.0f;
            }
        }

        if (Hitting_Timer > 0.0f)
        {
            Hitting_Timer -= Time.deltaTime;
            if (Hitting_Timer < 0.0f)
            {
                Hitting_Timer = 0.0f;
                Hitcolor.material.color = Color.white;
            }
        }

        if (TrapH_Timer > 0.0f)
        {
            TrapH_Timer -= Time.deltaTime;
            if (TrapH_Timer < 0.0f)
            {
                TrapH_Timer = 0.0f;
            }
        }

    } // �÷��̾� ��Ÿ��
    private void Player_moving()
    {
        if(Attack_MotionStop_Timer > 0 || Defense_MotionStop_Timer > 0 || Dash_Last_Timer > 0)
        {
            return;
        }
        moveDir.x = Input.GetAxisRaw("Horizontal");
        moveDir.y = rigid.velocity.y;
        rigid.velocity = moveDir * Player_Speed * SlowForce;

    }//�÷��̾� �̵�
    private void Player_checkGrounded()
    {
        IsGround = false;
        if (verticalVelocity > 0f)
        {
            return;
        }
        RaycastHit2D hit = Physics2D.BoxCast
        (collbox.bounds.center, collbox.bounds.size, 0f, Vector2.down, Raylength, LayerMask.GetMask("Ground"));

        if (hit)
        {
            IsGround = true;
        }
    }//�÷��̾� �ٴ�üũ
    private void Player_jump()
    {
        if(IsGround == false || Attack_MotionStop_Timer > 0 || Defense_MotionStop_Timer > 0)
        {
            return;
        }
        if(Input.GetKeyDown(KeyCode.Space))
        {
            IsJump = true;
        }
    }//�÷��̾� ����
    private void checkGravity()
    {
        if (Attack_MotionStop_Timer > 0 || Defense_MotionStop_Timer > 0 || Dash_Last_Timer > 0)
        {
            return;
        }
        else if (IsGround == false)
        {
            verticalVelocity += Physics.gravity.y * Time.deltaTime;
        }
        else if (IsJump == true)
        {
            IsJump = false;
            verticalVelocity = Jump_Force;
        }
        else if (IsGround == true )
        {
            verticalVelocity = -1f;
        }
        rigid.velocity = new Vector2(rigid.velocity.x, verticalVelocity);
    }//�÷��̾� �߷� ��Ʈ��
    private void doAnimi()
    {
        anim.SetInteger("Hor", (int)moveDir.x);
        anim.SetBool("IsGround", IsGround);
    }//�÷��̾� �ִϸ��̼�
    private void Player_Dash()
    {
        if(DoubleCastTimer > 0 || Attack_MotionStop_Timer > 0 || Defense_MotionStop_Timer > 0)
        {
            return;
        }
        else if (Dash_Cooldown_Timer == 0.0f && Input.GetKeyDown(KeyCode.L))
        {
            IsDash = true;
            Dash_Cooldown_Timer = Dash_Cooldown;
        }

    }//�÷��̾� �뽬
    private void Player_DashCast()
    { 
        if(IsDash == false)
        {
            return;
        }
        else if (IsDash == true)
        {
            IsDash = false;
            Dash_Last_Timer = 0.1f;
            float fixedforce = transform.localScale.x > 0 ? 1.0f : -1.0f;
            rigid.velocity = new Vector2(DashForce.x * fixedforce , DashForce.y);
            //rigid.AddForce(new Vector2(DashForce.x * fixedforce, DashForce.y), ForceMode2D.Impulse);

        }
    }
    private void Player_checkDirection()
    {
        Vector2 scale = transform.localScale;
        if (moveDir.x > 0 && scale.x != 1.0f)
        {
            scale.x = 1.0f;
            transform.localScale = scale;
        }
        else if (moveDir.x < 0 && scale.x != -1.0)
        {
            scale.x = -1.0f;
            transform.localScale = scale;
        }
    }// �÷��̾� ������ȯ
    public float Player_SendDamage()
    {
        float damage = Player_Damage;
        return damage;
    }
    // �÷��̾� ������ ����
    private void Player_InforUi()
    {
        playerHpFill.fillAmount = Player_Nowhp / Player_Maxhp;
        float curxp = PlayerManager.instance.Plaeyr_UiXP();
        playerXpFill.fillAmount = curxp;
        float gold = PlayerManager.instance.SendGold();
        playerGoldText.text = $"{gold} G";
    }
    //�÷��̾� UI
    private void Player_TextSet()
    {
        if(ReAttack_Cooldown_Timer > 0)
        {
            playerAtkText.enabled = true;
        }
        else
        {
            playerAtkText.enabled = false;
        }
        if (Defense_Cooldown_Timer > 0)
        {
            playerDefText.enabled = true;
        }
        else
        {
            playerDefText.enabled = false;
        }
        if (Dash_Cooldown_Timer > 0)
        {
            playerDashText.enabled = true;
        }
        else
        {
            playerDashText.enabled = false;
        }
        if (PotionCoolTimer > 0)
        {
            playerPotionText.enabled = true;
        }
        else
        {
            playerPotionText.enabled = false;
        }
        playerAtkText.text = ReAttack_Cooldown_Timer.ToString("F1");
        playerDefText.text = Defense_Cooldown_Timer.ToString("F1");
        playerDashText.text = Dash_Cooldown_Timer.ToString("F1");
        playerPotionText.text = PotionCoolTimer.ToString("F1");
    }//�÷��̾� ��ų UI ��Ÿ�� �ؽ�ó
    public void Infor_StatUpBut1() //�÷��̾� ���ݷ� ���� ��ư UI
    {
        Player_Damage = PlayerManager.instance.GetStatButton(0, Player_Damage);
    }
    public void Infor_StatUpBut2() //�÷��̾� ������ ���� ��ư UI
    {
        Player_Nowhp = PlayerManager.instance.GetStatButton(2, Player_Nowhp);
        Player_Maxhp = PlayerManager.instance.GetStatButton(1, Player_Maxhp);
    }
    private void Plaeyr_Healing()
    {
        if(Htiemr > 0)
        {
            Htiemr -= Time.deltaTime;
            if(Htiemr < 0)
            {
                Htiemr = 15f;
                if (Player_Nowhp < Player_Maxhp - Player_Healing)
                {
                    Player_Nowhp += Player_Healing;
                }
                else
                {
                    Player_Nowhp = Player_Maxhp;
                }
            }
        }
    }//�÷��̾� ���
    private void Player_Potion()
    {
        if (Input.GetKeyDown(KeyCode.P) && PlayerManager.instance.SendPotion() > 0 && PotionCoolTimer == 0)
        {
            if(Player_Nowhp < Player_Maxhp - 5)
            {
                Player_Nowhp += 5;
                PlayerManager.instance.UsePotion();
                PotionCoolTimer = 3f;
            }
            else
            {
                Player_Nowhp = Player_Maxhp;
                PlayerManager.instance.UsePotion();
                PotionCoolTimer = 3f;
            }
        }
    }//�÷��̾� ����

}
