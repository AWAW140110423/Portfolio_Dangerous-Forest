using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Ex : MonoBehaviour
{
    // Start is called before the first frame update


    float LetgoRia;

    float[] ria;



    void Start()
    {
        ria[0] = 5315;
        ria[1] = 5669;


    }



    // Update is called once per frame
    void Update()
    {
        Debug.Log(LetgoRia);
    }
}
